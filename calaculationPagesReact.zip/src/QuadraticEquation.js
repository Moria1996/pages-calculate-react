import * as React from "react";
class QuadraticEquation extends React.Component {
    state = {
        a: '',
        b: '',
        c: '',
        x1: '',
        x2: '',
        text: ''
    }
    render() {
        return (
            <div>
                <div className="row mb-3">
                    <h5>Please enter a, b, and c for the calculation</h5>
                    <br/><br/>
                    <label htmlFor="inputEmail3" className="col-sm-1 col-form-label">a:</label>
                    <div className="col-sm-5">
                        <input onChange={this.aChange} type="number" className="form-control" id="inputEmail3"/>
                    </div>
                </div>
                <div className="row mb-3">
                    <label htmlFor="inputPassword3" className="col-sm-1 col-form-label">b:</label>
                    <div className="col-sm-5">
                        <input onChange={this.bChange} type="number" className="form-control"
                               id="inputPassword3"/>
                    </div>
                </div>
                <div className="row mb-3">
                    <label htmlFor="inputPassword3" className="col-sm-1 col-form-label">c:</label>
                    <div className="col-sm-5">
                        <input onChange={this.cChange} type="number" className="form-control"
                               id="inputPassword3"/>
                    </div>
                </div>
                <br/>
                <br/>
                <button onClick={this.calculateAnswer} type="button" className="btn btn-primary" >Calculate Answer
                </button>
                <div> {this.state.text}</div>
            </div>
        )
    }
    aChange = (event) => {
        this.setState({
            a: event.target.value
        })
    }
    bChange = (event) => {
        this.setState({
            b: event.target.value
        })
    }
    cChange = (event) => {
        this.setState({
            c: event.target.value
        })
    }
    calculateAnswer = () => {
        let ans1 = 0;
        let ans2 = 0;
        if (this.state.a != 0) {
            ans1 = Math.pow(this.state.b, 2) - 4 * this.state.a * this.state.c
            if (ans1 >= 0) {
                ans1 = Math.sqrt(ans1);
                ans2 = -(this.state.b) - ans1;
                ans1 = -(this.state.b) + ans1;
                ans1 = ans1 / (2 * this.state.a);
                ans2 = ans2 / (2 * this.state.a);
                if(ans1!=ans2){
                    this.setState({
                        x1: ans1,
                        x2: ans2,
                        text: "x1= " + ans1 + " x2= " + ans2
                    })
                }
                else {
                    this.setState({
                        x1: ans1,
                        text: "x1= " + ans1
                    })
                }
            } else {
                this.setState({
                    text: "there is no solution for the equation"
                })
            }
        } else {
            this.setState({
                text: "there is no solution for the equation"
            })
        }
    }
}
export default QuadraticEquation;
