import React from "react";

function NavigationBar(){
    return(
        <div>
            <head>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
                      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3"
                      crossOrigin="anonymous"/></head>
            <body>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
                    integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
                    crossOrigin="anonymous"></script></body>
            <form>
                <h1>Hello! what do you want to calculate today? </h1>
                <br/><br/>
                <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
                    <div className="container-fluid">
                        <div className="collapse navbar-collapse" id="navbarNavDropdown">
                            <ul className="navbar-nav">
                                <li className="nav-item">
                                    <a className="nav-link active" aria-current="page" href="/equation">Quadratic Equation</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link active" href="/triangle_area">Triangle Area</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link active" href="/pythagorean">Pythagorean</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>
                <br/><br/>
            </form>
        </div>
    )
}
export default NavigationBar;
