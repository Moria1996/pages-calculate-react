import './App.css';
import QuadraticEquation from "./QuadraticEquation";
import TriangleArea from "./TriangleArea";
import Pythagorean from "./Pythagorean";
import * as React from "react";
import {Router, Route, Switch} from "react-router-dom";
import createHistory from "history/createBrowserHistory";
import NavigationBar from "./NavigationBar";
export const history = createHistory();
class App extends React.Component{
  render() {
    return (
        <div>
            <Router history={history}>
                <NavigationBar/>
                <Switch>
                    <Route path={"/equation"} component={QuadraticEquation}/>
                    <Route path={"/triangle_area"} component={TriangleArea}/>
                    <Route path={"/pythagorean"} component={Pythagorean}/>
                </Switch>
            </Router>
        </div>
    );
  }
}



export default App;
