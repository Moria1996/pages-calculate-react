import * as React from "react";
class Pythagorean extends React.Component {
    state = {
        a: '',
        b: '',
        c: ''
    }
    render() {
        return (
            <div>
                <div className="row mb-3">
                    <h5>Please enter a, b, and c for the calculation</h5>
                    <br/><br/>
                    <label htmlFor="inputEmail3" className="col-sm-1 col-form-label">a:</label>
                    <div className="col-sm-5">
                        <input value={this.state.a} type="number" onChange={this.aChange} className="form-control" id="inputEmail3"/>
                    </div>
                </div>
                <div className="row mb-3">
                    <label htmlFor="inputPassword3" className="col-sm-1 col-form-label">b:</label>
                    <div className="col-sm-5">
                        <input value={this.state.b} type="number" onChange={this.bChange} className="form-control"
                               id="inputPassword3"/>
                    </div>
                </div>
                <div className="row mb-3">
                    <label htmlFor="inputPassword3" className="col-sm-1 col-form-label">c:</label>
                    <div className="col-sm-5">
                        <input value={this.state.c} type="number" onChange={this.cChange} className="form-control"
                               id="inputPassword3"/>
                    </div>
                </div>
                <br/>
                <button onClick={this.clear} type="button" className="btn btn-primary" >Clear</button>
            </div>
        )
    }
    clear=()=>{
        this.setState({
            a: '',
            b: '',
            c: ''
        })
    }
    aChange = (event) => {
        this.setState({
            a: event.target.value
        }, ()=>{
            if (this.state.c != ''&&this.state.a != '')
                this.calculateB();
            if (this.state.b != ''&&this.state.a != '')
                this.calculateC();
        });
    }
    bChange = (event) => {
        this.setState({
            b: event.target.value
        }, ()=>{
            if (this.state.c != ''&&this.state.b != '')
                this.calculateA();
            if (this.state.a != ''&&this.state.b != '')
                this.calculateC();
        })
    }
    cChange = (event) => {
        this.setState({
            c: event.target.value
        },()=>{
            if (this.state.b != ''&&this.state.c != '')
                this.calculateA();
            if (this.state.a != ''&&this.state.c != '')
                this.calculateB();
        })
    }
    calculateA = () => {
        let newA = Math.pow(this.state.c, 2) - Math.pow(this.state.b, 2);
        newA = Math.sqrt(newA);
        this.setState({
            a: newA
        })
    }
    calculateB = () => {
        let newB = Math.pow(this.state.c, 2) - Math.pow(this.state.a, 2);
        newB = Math.sqrt(newB);
        this.setState({
            b: newB
        })
    }
    calculateC = () => {
        let newC = Math.pow(this.state.a, 2) + Math.pow(this.state.b, 2);
        newC = Math.sqrt(newC);
        this.setState({
            c: newC
        })
    }
}
export default Pythagorean;
