import * as React from "react";
class TriangleArea extends React.Component{
    state={
        base: '',
        height: '',
        area: ''
    }
    render() {
        return(
            <div>
                <h5>Please enter base and height of the triangle for the area calculation</h5>
                <br/>
                <div className="row mb-3">
                    <label htmlFor="inputEmail3" className="col-sm-1 col-form-label">Base:</label>
                    <div className="col-sm-5">
                        <input onChange={this.baseChange} type="number" className="form-control" id="inputEmail3"/>
                    </div>
                </div>
                <div className="row mb-3">
                    <label htmlFor="inputPassword3" className="col-sm-1 col-form-label">Height:</label>
                    <div className="col-sm-5">
                        <input onChange={this.heightChange} type="number" className="form-control" id="inputPassword3"/>
                    </div>
                </div>
                <br/>
                <button type="button" class="btn btn-primary" onClick={this.calculateArea}>calculate area</button>
                {
                    this.state.area!=''&&
                    <div>The area is: {this.state.area}</div>
                }
            </div>
        )
    }
    baseChange = (event) => {
        this.setState({
            base: event.target.value
        })
    }
    heightChange = (event) => {
        this.setState({
            height: event.target.value
        })
    }
    calculateArea=()=>{
        this.setState({
            area: this.state.base*this.state.height/2
        })
    }
}
export default TriangleArea;
